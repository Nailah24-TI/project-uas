<footer class="bg-white shadow p-4 mt-5">
    <div class="row">
        <div class="col text-center text-md-start">
            <p class="mb-0">
                © <span class="current-year"></span> Your App. All rights reserved.
            </p>
        </div>
    </div>
</footer>
