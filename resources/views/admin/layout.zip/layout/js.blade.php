<script src="{{ asset('assets/js/corporate-ui-dashboard.js') }}"></script>
